import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';

const Hint = () => (
  <div className='h-full flex items-center justify-center p-8'>
    <div className='max-w-md text-center'>
      <h1 className='text-2xl font-semibold text-ui-text mb-2'>Routify UI Library</h1>
      <p className='text-sm text-ui-text-2 leading-relaxed'>
        本工程目前只承载原子组件库。请运行 <code className='font-mono text-ui-text bg-ui-bg-subtle px-1.5 py-0.5 rounded'>npm run storybook</code> 查看组件展示。
      </p>
    </div>
  </div>
);

createRoot(document.getElementById('root')).render(<Hint />);
