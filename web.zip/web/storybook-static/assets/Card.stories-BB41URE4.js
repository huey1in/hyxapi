import{j as d}from"./jsx-runtime-DFAAy_2V.js";import"./index-Bc2G9s8g.js";import{C as e}from"./Card-BLdKUx7J.js";import{B as r}from"./Button-Yv8kz5f4.js";import"./tokens-DrfCP7vW.js";const u={title:"UI/Card",component:e},i=({title:l,children:o})=>d.jsxs("div",{className:"mb-5",children:[d.jsx("div",{className:"text-[11px] uppercase tracking-wider text-ui-text-3 mb-2",children:l}),o]}),a=()=>d.jsxs("div",{className:"max-w-[900px] space-y-3",children:[d.jsx(i,{title:"variant",children:d.jsxs("div",{className:"grid grid-cols-3 gap-3",children:[d.jsx(e,{children:"plain (与 page-bg 同色 + 边框，默认)"}),d.jsx(e,{variant:"outlined",children:"outlined (透明 + 边框)"}),d.jsx(e,{variant:"filled",children:"filled (bg-ui-bg-subtle 实心)"})]})}),d.jsx(i,{title:"radius",children:d.jsxs("div",{className:"grid grid-cols-4 gap-3",children:[d.jsx(e,{radius:"md",children:"md (rounded-xl)"}),d.jsx(e,{radius:"lg",children:"lg (rounded-2xl, 默认)"}),d.jsx(e,{radius:"xl",children:"xl (rounded-3xl)"}),d.jsx(e,{radius:"xxl",children:"xxl (rounded-[20px])"})]})}),d.jsx(i,{title:"padding",children:d.jsxs("div",{className:"grid grid-cols-4 gap-3",children:[d.jsx(e,{padding:"none",children:"none"}),d.jsx(e,{padding:"sm",children:"sm"}),d.jsx(e,{padding:"md",children:"md (默认)"}),d.jsx(e,{padding:"lg",children:"lg"})]})}),d.jsx(i,{title:"header / footer slot",children:d.jsx(e,{padding:"md",header:d.jsx("div",{className:"text-sm font-semibold text-ui-text",children:"标题"}),footer:d.jsxs("div",{className:"flex justify-end gap-2",children:[d.jsx(r,{size:"sm",children:"取消"}),d.jsx(r,{size:"sm",children:"确认"})]}),children:d.jsx("p",{className:"text-sm text-ui-text-2",children:"这里是卡片主体内容。Header / Footer 自带分隔线和 padding。"})})}),d.jsx(i,{title:"interactive",children:d.jsxs("div",{className:"grid grid-cols-2 gap-3",children:[d.jsx(e,{interactive:"hover",onClick:()=>alert("clicked"),children:"interactive='hover'"}),d.jsx(e,{interactive:"lift",onClick:()=>alert("clicked"),children:"interactive='lift' (带 shadow-md)"})]})})]});a.__docgenInfo={description:"",methods:[],displayName:"AllVariants"};var n,s,t;a.parameters={...a.parameters,docs:{...(n=a.parameters)==null?void 0:n.docs,source:{originalSource:`() => <div className='max-w-[900px] space-y-3'>
    <Row title='variant'>
      <div className='grid grid-cols-3 gap-3'>
        <Card>plain (与 page-bg 同色 + 边框，默认)</Card>
        <Card variant='outlined'>outlined (透明 + 边框)</Card>
        <Card variant='filled'>filled (bg-ui-bg-subtle 实心)</Card>
      </div>
    </Row>
    <Row title='radius'>
      <div className='grid grid-cols-4 gap-3'>
        <Card radius='md'>md (rounded-xl)</Card>
        <Card radius='lg'>lg (rounded-2xl, 默认)</Card>
        <Card radius='xl'>xl (rounded-3xl)</Card>
        <Card radius='xxl'>xxl (rounded-[20px])</Card>
      </div>
    </Row>
    <Row title='padding'>
      <div className='grid grid-cols-4 gap-3'>
        <Card padding='none'>none</Card>
        <Card padding='sm'>sm</Card>
        <Card padding='md'>md (默认)</Card>
        <Card padding='lg'>lg</Card>
      </div>
    </Row>
    <Row title='header / footer slot'>
      <Card padding='md' header={<div className='text-sm font-semibold text-ui-text'>标题</div>} footer={<div className='flex justify-end gap-2'>
            <Button size='sm'>取消</Button>
            <Button size='sm'>确认</Button>
          </div>}>
        <p className='text-sm text-ui-text-2'>这里是卡片主体内容。Header / Footer 自带分隔线和 padding。</p>
      </Card>
    </Row>
    <Row title='interactive'>
      <div className='grid grid-cols-2 gap-3'>
        <Card interactive='hover' onClick={() => alert('clicked')}>
          interactive='hover'
        </Card>
        <Card interactive='lift' onClick={() => alert('clicked')}>
          interactive='lift' (带 shadow-md)
        </Card>
      </div>
    </Row>
  </div>`,...(t=(s=a.parameters)==null?void 0:s.docs)==null?void 0:t.source}}};const v=["AllVariants"];export{a as AllVariants,v as __namedExportsOrder,u as default};
