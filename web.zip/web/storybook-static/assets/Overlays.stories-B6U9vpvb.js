import{j as e}from"./jsx-runtime-DFAAy_2V.js";import{r as m}from"./index-Bc2G9s8g.js";import{r as j}from"./index-BO6cjGmN.js";import{a as g}from"./tokens-DrfCP7vW.js";import{I as N}from"./IconButton-BnpmFXWU.js";import{B as l}from"./Button-Yv8kz5f4.js";import{X as w}from"./x-Bzu-zyl5.js";import{T as R}from"./Tag-a08qfjaU.js";import{T as W}from"./trash-2-BCUJgxuz.js";import{T as U}from"./triangle-alert-wAXkQR6E.js";const k=({open:s,onClose:t,maxWidth:r=500,maxHeight:a="calc(100vh - 32px)",closeOnBackdrop:n=!0,blockScroll:o=!0,zIndex:d=200,variant:c="flush",children:u})=>(m.useEffect(()=>{if(!s)return;const i=y=>y.key==="Escape"&&(t==null?void 0:t());document.addEventListener("keydown",i);let x;return o&&(x=document.body.style.overflow,document.body.style.overflow="hidden"),()=>{document.removeEventListener("keydown",i),o&&(document.body.style.overflow=x)}},[s,t,o]),!s||typeof document>"u"?null:j.createPortal(e.jsx("div",{className:"fixed inset-0 flex items-center justify-center p-4",style:{background:"rgba(0,0,0,0.45)",backdropFilter:"blur(2px)",zIndex:d},onClick:n?t:void 0,children:e.jsx("div",{className:g("bg-ui-bg-elevated border border-ui-border rounded-2xl shadow-2xl w-full overflow-hidden",c==="body-shell"&&"p-6"),style:{maxWidth:r,maxHeight:a},onClick:i=>i.stopPropagation(),children:u})}),document.body)),L=({open:s,onClose:t,title:r,children:a,footer:n,width:o=500,loading:d=!1,hideFooter:c=!1,onConfirm:u,confirmText:i="确定",cancelText:x="取消"})=>e.jsxs(k,{open:s,onClose:t,maxWidth:o,children:[e.jsxs("div",{className:"flex items-center justify-between px-6 pt-5 pb-4 border-b border-ui-border",children:[e.jsx("h3",{className:"text-base font-semibold text-ui-text",style:{letterSpacing:"-0.02em"},children:r}),e.jsx(N,{icon:w,onClick:t,"aria-label":"close"})]}),e.jsx("div",{className:"px-6 py-5 max-h-[70vh] overflow-y-auto space-y-4",children:a}),!c&&e.jsx("div",{className:"flex justify-end gap-2.5 px-6 py-4 border-t border-ui-border",children:n||e.jsxs(e.Fragment,{children:[e.jsx(l,{onClick:t,children:x}),e.jsx(l,{loading:d,onClick:u||t,children:i})]})})]});L.__docgenInfo={description:"",methods:[],displayName:"Modal",props:{width:{defaultValue:{value:"500",computed:!1},required:!1},loading:{defaultValue:{value:"false",computed:!1},required:!1},hideFooter:{defaultValue:{value:"false",computed:!1},required:!1},confirmText:{defaultValue:{value:"'确定'",computed:!1},required:!1},cancelText:{defaultValue:{value:"'取消'",computed:!1},required:!1}}};const P=({open:s,onClose:t,title:r,description:a,onConfirm:n,confirmText:o="确定",cancelText:d="取消",loading:c=!1})=>e.jsxs(k,{open:s,onClose:t,maxWidth:400,children:[e.jsxs("div",{className:"p-6 space-y-3",children:[r&&e.jsx("h3",{className:"text-base font-semibold text-ui-text",style:{letterSpacing:"-0.02em"},children:r}),a&&e.jsx("p",{className:"text-sm text-ui-text-2 leading-relaxed",children:a})]}),e.jsxs("div",{className:"flex justify-end gap-2.5 px-6 py-4 border-t border-ui-border",children:[e.jsx(l,{onClick:t,children:d}),e.jsx(l,{loading:c,onClick:()=>{n==null||n(),t==null||t()},children:o})]})]});P.__docgenInfo={description:"",methods:[],displayName:"ConfirmDialog",props:{confirmText:{defaultValue:{value:"'确定'",computed:!1},required:!1},cancelText:{defaultValue:{value:"'取消'",computed:!1},required:!1},loading:{defaultValue:{value:"false",computed:!1},required:!1}}};const X=({open:s,onClose:t,placement:r="right",width:a=600,title:n,headerExtra:o,footer:d,children:c})=>{if(m.useEffect(()=>{if(!s)return;const i=y=>y.key==="Escape"&&(t==null?void 0:t());document.addEventListener("keydown",i);const x=document.body.style.overflow;return document.body.style.overflow="hidden",()=>{document.removeEventListener("keydown",i),document.body.style.overflow=x}},[s,t]),!s||typeof document>"u")return null;const u=r==="left"?"left-0":"right-0";return j.createPortal(e.jsxs("div",{className:"fixed inset-0 z-[200]",children:[e.jsx("div",{className:"absolute inset-0 bg-black/45 backdrop-blur-[2px]",onClick:t}),e.jsxs("div",{className:g("absolute top-0 bottom-0 bg-ui-bg-elevated shadow-2xl flex flex-col",u),style:{width:a},children:[e.jsxs("div",{className:"flex items-center justify-between gap-3 px-6 py-4 border-b border-ui-border flex-shrink-0",children:[e.jsx("div",{className:"flex items-center gap-2 min-w-0 flex-1",children:n}),e.jsxs("div",{className:"flex items-center gap-2 flex-shrink-0",children:[o,e.jsx(N,{icon:w,onClick:t,"aria-label":"close"})]})]}),e.jsx("div",{className:"flex-1 overflow-y-auto",children:c}),d&&e.jsx("div",{className:"flex items-center justify-end gap-2 px-6 py-3.5 border-t border-ui-border flex-shrink-0",children:d})]})]}),document.body)},G={top:{container:"top-0 left-0 right-0",sizeKey:"height"},bottom:{container:"bottom-0 left-0 right-0",sizeKey:"height"},left:{container:"top-0 bottom-0 left-0",sizeKey:"width"},right:{container:"top-0 bottom-0 right-0",sizeKey:"width"}},S=({open:s,onClose:t,placement:r="right",size:a=320,title:n,showBackdrop:o=!0,children:d})=>{if(m.useEffect(()=>{if(!s)return;const u=i=>i.key==="Escape"&&(t==null?void 0:t());return document.addEventListener("keydown",u),()=>document.removeEventListener("keydown",u)},[s,t]),!s||typeof document>"u")return null;const c=G[r];return j.createPortal(e.jsxs("div",{className:"fixed inset-0 z-[200]",children:[o&&e.jsx("div",{className:"absolute inset-0 bg-black/30",onClick:t}),e.jsxs("div",{className:g("absolute bg-ui-bg-elevated shadow-2xl flex flex-col",c.container),style:{[c.sizeKey]:a},children:[n&&e.jsxs("div",{className:"flex items-center justify-between gap-3 px-5 py-4 border-b border-ui-border flex-shrink-0",children:[e.jsx("div",{className:"text-base font-semibold text-ui-text",children:n}),e.jsx(N,{icon:w,onClick:t,"aria-label":"close"})]}),e.jsx("div",{className:"flex-1 overflow-y-auto",children:d})]})]}),document.body)},re={title:"UI/Overlays"},p=()=>{const[s,t]=m.useState(!1);return e.jsxs(e.Fragment,{children:[e.jsx(l,{onClick:()=>t(!0),children:"打开 Modal"}),e.jsxs(L,{open:s,onClose:()=>t(!1),title:"创建新条目",confirmText:"创建",onConfirm:()=>{alert("created"),t(!1)},children:[e.jsx("p",{className:"text-sm text-ui-text-2 leading-relaxed",children:"Modal = ModalShell + 标准 header/body/footer。下面演示 body 内容会自动 max-h-[70vh] 滚动。"}),e.jsx("div",{className:"space-y-2",children:Array.from({length:30}).map((r,a)=>e.jsxs("div",{className:"text-sm text-ui-text-3",children:["第 ",a+1," 行内容"]},a))})]})]})},f=()=>{const[s,t]=m.useState(!1);return e.jsxs(e.Fragment,{children:[e.jsx(l,{onClick:()=>t(!0),icon:W,children:"删除示例"}),e.jsx(P,{open:s,onClose:()=>t(!1),title:"确定删除？",description:"此操作不可恢复，将永久删除该条目及关联数据。",confirmText:"删除",onConfirm:()=>alert("deleted")})]})},h=()=>{const[s,t]=m.useState(!1);return e.jsxs(e.Fragment,{children:[e.jsx(l,{onClick:()=>t(!0),children:"打开 SlideOver"}),e.jsx(X,{open:s,onClose:()=>t(!1),placement:"right",width:520,title:e.jsxs(e.Fragment,{children:[e.jsx(R,{color:"blue",children:"编辑"}),e.jsx("span",{className:"text-base font-semibold text-ui-text",children:"编辑套餐"})]}),footer:e.jsxs(e.Fragment,{children:[e.jsx(l,{onClick:()=>t(!1),children:"取消"}),e.jsx(l,{onClick:()=>t(!1),children:"保存"})]}),children:e.jsxs("div",{className:"p-6 space-y-4",children:[e.jsx("p",{className:"text-sm text-ui-text-2",children:"SlideOver 适合编辑型大表单 — 比 Modal 更大且滚动友好。"}),Array.from({length:25}).map((r,a)=>e.jsxs("div",{className:"text-sm text-ui-text-3 py-1",children:["表单字段 ",a+1]},a))]})})]})},v=()=>{const[s,t]=m.useState(!1),[r,a]=m.useState(!1);return e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"flex gap-2",children:[e.jsx(l,{onClick:()=>t(!0),children:"右侧 Drawer"}),e.jsx(l,{onClick:()=>a(!0),children:"底部 Drawer"})]}),e.jsx(S,{open:s,onClose:()=>t(!1),title:"侧栏通知",children:e.jsx("div",{className:"p-5 text-sm text-ui-text-2",children:"Drawer 与 SlideOver 类似，但支持四个方向。"})}),e.jsx(S,{open:r,onClose:()=>a(!1),placement:"bottom",size:240,title:"底部抽屉",children:e.jsx("div",{className:"p-5 text-sm text-ui-text-2",children:"从底部滑入，常用于移动端动作面板。"})})]})},b=()=>{const[s,t]=m.useState(!1);return e.jsxs(e.Fragment,{children:[e.jsx(l,{onClick:()=>t(!0),children:"打开 ModalShell (自定义内容)"}),e.jsx(k,{open:s,onClose:()=>t(!1),maxWidth:420,children:e.jsxs("div",{className:"p-8 text-center",children:[e.jsx(U,{size:32,className:"mx-auto text-amber-500 mb-3"}),e.jsx("div",{className:"text-base font-semibold text-ui-text mb-1",children:"完全自定义内容"}),e.jsx("div",{className:"text-xs text-ui-text-3",children:"当 Modal 标准结构不满足时用 ModalShell。"})]})})]})};p.__docgenInfo={description:"",methods:[],displayName:"ModalDemo"};f.__docgenInfo={description:"",methods:[],displayName:"ConfirmDialogDemo"};h.__docgenInfo={description:"",methods:[],displayName:"SlideOverDemo"};v.__docgenInfo={description:"",methods:[],displayName:"DrawerDemo"};b.__docgenInfo={description:"",methods:[],displayName:"ModalShellRaw"};var O,D,M;p.parameters={...p.parameters,docs:{...(O=p.parameters)==null?void 0:O.docs,source:{originalSource:`() => {
  const [open, setOpen] = useState(false);
  return <>
      <Button onClick={() => setOpen(true)}>打开 Modal</Button>
      <Modal open={open} onClose={() => setOpen(false)} title='创建新条目' confirmText='创建' onConfirm={() => {
      alert('created');
      setOpen(false);
    }}>
        <p className='text-sm text-ui-text-2 leading-relaxed'>
          Modal = ModalShell + 标准 header/body/footer。下面演示 body 内容会自动 max-h-[70vh] 滚动。
        </p>
        <div className='space-y-2'>
          {Array.from({
          length: 30
        }).map((_, i) => <div key={i} className='text-sm text-ui-text-3'>第 {i + 1} 行内容</div>)}
        </div>
      </Modal>
    </>;
}`,...(M=(D=p.parameters)==null?void 0:D.docs)==null?void 0:M.source}}};var B,_,T;f.parameters={...f.parameters,docs:{...(B=f.parameters)==null?void 0:B.docs,source:{originalSource:`() => {
  const [open, setOpen] = useState(false);
  return <>
      <Button onClick={() => setOpen(true)} icon={Trash2}>删除示例</Button>
      <ConfirmDialog open={open} onClose={() => setOpen(false)} title='确定删除？' description='此操作不可恢复，将永久删除该条目及关联数据。' confirmText='删除' onConfirm={() => alert('deleted')} />
    </>;
}`,...(T=(_=f.parameters)==null?void 0:_.docs)==null?void 0:T.source}}};var E,C,z;h.parameters={...h.parameters,docs:{...(E=h.parameters)==null?void 0:E.docs,source:{originalSource:`() => {
  const [open, setOpen] = useState(false);
  return <>
      <Button onClick={() => setOpen(true)}>打开 SlideOver</Button>
      <SlideOver open={open} onClose={() => setOpen(false)} placement='right' width={520} title={<>
            <Tag color='blue'>编辑</Tag>
            <span className='text-base font-semibold text-ui-text'>编辑套餐</span>
          </>} footer={<>
            <Button onClick={() => setOpen(false)}>取消</Button>
            <Button onClick={() => setOpen(false)}>保存</Button>
          </>}>
        <div className='p-6 space-y-4'>
          <p className='text-sm text-ui-text-2'>SlideOver 适合编辑型大表单 — 比 Modal 更大且滚动友好。</p>
          {Array.from({
          length: 25
        }).map((_, i) => <div key={i} className='text-sm text-ui-text-3 py-1'>表单字段 {i + 1}</div>)}
        </div>
      </SlideOver>
    </>;
}`,...(z=(C=h.parameters)==null?void 0:C.docs)==null?void 0:z.source}}};var F,I,q;v.parameters={...v.parameters,docs:{...(F=v.parameters)==null?void 0:F.docs,source:{originalSource:`() => {
  const [open, setOpen] = useState(false);
  const [bottom, setBottom] = useState(false);
  return <>
      <div className='flex gap-2'>
        <Button onClick={() => setOpen(true)}>右侧 Drawer</Button>
        <Button onClick={() => setBottom(true)}>底部 Drawer</Button>
      </div>
      <Drawer open={open} onClose={() => setOpen(false)} title='侧栏通知'>
        <div className='p-5 text-sm text-ui-text-2'>Drawer 与 SlideOver 类似，但支持四个方向。</div>
      </Drawer>
      <Drawer open={bottom} onClose={() => setBottom(false)} placement='bottom' size={240} title='底部抽屉'>
        <div className='p-5 text-sm text-ui-text-2'>从底部滑入，常用于移动端动作面板。</div>
      </Drawer>
    </>;
}`,...(q=(I=v.parameters)==null?void 0:I.docs)==null?void 0:q.source}}};var K,V,A;b.parameters={...b.parameters,docs:{...(K=b.parameters)==null?void 0:K.docs,source:{originalSource:`() => {
  const [open, setOpen] = useState(false);
  return <>
      <Button onClick={() => setOpen(true)}>打开 ModalShell (自定义内容)</Button>
      <ModalShell open={open} onClose={() => setOpen(false)} maxWidth={420}>
        <div className='p-8 text-center'>
          <AlertTriangle size={32} className='mx-auto text-amber-500 mb-3' />
          <div className='text-base font-semibold text-ui-text mb-1'>完全自定义内容</div>
          <div className='text-xs text-ui-text-3'>当 Modal 标准结构不满足时用 ModalShell。</div>
        </div>
      </ModalShell>
    </>;
}`,...(A=(V=b.parameters)==null?void 0:V.docs)==null?void 0:A.source}}};const ne=["ModalDemo","ConfirmDialogDemo","SlideOverDemo","DrawerDemo","ModalShellRaw"];export{f as ConfirmDialogDemo,v as DrawerDemo,p as ModalDemo,b as ModalShellRaw,h as SlideOverDemo,ne as __namedExportsOrder,re as default};
