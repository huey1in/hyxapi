import{j as e}from"./jsx-runtime-DFAAy_2V.js";import{r as w}from"./index-Bc2G9s8g.js";import{C as ne}from"./Card-BLdKUx7J.js";import{c as I,a as d}from"./tokens-DrfCP7vW.js";import{B as l,L as oe}from"./Button-Yv8kz5f4.js";import{I as S}from"./IconButton-BnpmFXWU.js";import{T as k}from"./triangle-alert-wAXkQR6E.js";import{C as re,I as le}from"./info-BPim9xgb.js";import{P as Z}from"./plus-CJWvk8nG.js";import{R as de}from"./refresh-cw-DF6RBdiH.js";/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ce=[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]],me=I("chevron-left",ce);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ue=[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]],xe=I("chevron-right",ue);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const pe=[["polyline",{points:"22 12 16 12 14 15 10 15 8 12 2 12",key:"o97t9d"}],["path",{d:"M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z",key:"oot6mr"}]],J=I("inbox",pe),Q=({title:t,actions:s,maxWidth:a="1400px",children:n})=>e.jsx("div",{className:"px-4 pt-8 pb-6 md:px-6 md:pt-10 md:pb-8",style:{backgroundColor:"var(--page-bg)"},children:e.jsxs("div",{className:"mx-auto",style:{maxWidth:a},children:[(t||s)&&e.jsxs("div",{className:"flex items-center justify-between gap-3 mb-5",children:[t&&e.jsx("h1",{className:"text-2xl md:text-3xl font-medium text-ui-text",style:{letterSpacing:"-0.02em"},children:t}),s&&e.jsx("div",{className:"flex items-center gap-1",children:s})]}),n]})});Q.__docgenInfo={description:"",methods:[],displayName:"PageShell",props:{maxWidth:{defaultValue:{value:"'1400px'",computed:!1},required:!1}}};const X=({title:t,description:s,children:a})=>e.jsxs(ne,{variant:"plain",radius:"xxl",padding:"lg",children:[(t||s)&&e.jsxs("div",{className:"mb-4",children:[t&&e.jsx("div",{className:"text-sm font-semibold text-ui-text",children:t}),s&&e.jsx("div",{className:"text-[11px] text-ui-text-3 mt-0.5",children:s})]}),e.jsx("div",{className:"space-y-3",children:a})]});X.__docgenInfo={description:"",methods:[],displayName:"SectionCard"};const ee=({icon:t=J,title:s,description:a,action:n,padding:i="lg"})=>e.jsxs("div",{className:d("flex flex-col items-center justify-center text-center text-ui-text-3",i==="lg"&&"py-16",i==="md"&&"py-10",i==="sm"&&"py-6"),children:[e.jsx("div",{className:"w-12 h-12 rounded-full bg-ui-bg-subtle flex items-center justify-center mb-3",children:e.jsx(t,{size:20})}),s&&e.jsx("div",{className:"text-sm text-ui-text-2 font-medium mb-1",children:s}),a&&e.jsx("div",{className:"text-xs text-ui-text-3 max-w-sm leading-relaxed",children:a}),n&&e.jsx("div",{className:"mt-4",children:n})]});ee.__docgenInfo={description:"",methods:[],displayName:"EmptyState",props:{icon:{defaultValue:{value:"Inbox",computed:!0},required:!1},padding:{defaultValue:{value:"'lg'",computed:!1},required:!1}}};const te=({items:t=[],value:s,onChange:a,size:n="md"})=>e.jsx("div",{className:"inline-flex items-center min-w-max gap-1 bg-ui-bg-subtle p-1 rounded-xl",children:t.map(i=>{const o=i.value===s;return e.jsx(l,{variant:"toggle",size:n,selected:o,disabled:i.disabled,onClick:()=>!i.disabled&&(a==null?void 0:a(i.value)),children:i.label},String(i.value))})});te.__docgenInfo={description:"",methods:[],displayName:"Tabs",props:{items:{defaultValue:{value:"[]",computed:!1},required:!1},size:{defaultValue:{value:"'md'",computed:!1},required:!1}}};const se=({page:t,pageSize:s,total:a,onChange:n,showRange:i=!0})=>{const o=Math.max(1,Math.ceil((a||0)/(s||1))),y=a===0?0:(t-1)*s+1,_=Math.min(t*s,a),N=c=>{c<1||c>o||c===t||n==null||n(c)};return e.jsxs("div",{className:"flex items-center justify-between gap-3 px-4 py-3 border-t border-ui-border text-sm",children:[i&&e.jsx("span",{className:"text-ui-text-3 tabular-nums",children:a>0?`${y}-${_} / ${a}`:"0"}),e.jsxs("div",{className:"flex items-center gap-1",children:[e.jsx(S,{icon:me,size:"sm",onClick:()=>N(t-1),disabled:t<=1,"aria-label":"prev"}),e.jsxs("span",{className:"px-3 py-2 text-ui-text tabular-nums",children:[t," / ",o]}),e.jsx(S,{icon:xe,size:"sm",onClick:()=>N(t+1),disabled:t>=o,"aria-label":"next"})]})]})};se.__docgenInfo={description:"",methods:[],displayName:"Pagination",props:{showRange:{defaultValue:{value:"true",computed:!1},required:!1}}};const he={info:"border-blue-500/30    bg-blue-500/5    text-ui-text-2",success:"border-emerald-500/30 bg-emerald-500/5 text-ui-text-2",warning:"border-amber-500/30   bg-amber-500/5   text-ui-text-2",danger:"border-ui-danger/30   bg-ui-danger-bg  text-ui-text-2"},fe={info:le,success:re,warning:k,danger:k},ge={info:"text-blue-600",success:"text-emerald-600",warning:"text-amber-600",danger:"text-ui-danger"},r=({kind:t="info",icon:s,title:a,children:n,action:i})=>{const o=s||fe[t];return e.jsxs("div",{className:d("flex items-start gap-2 px-4 py-3 rounded-xl border",he[t]),children:[e.jsx(o,{size:14,className:d("flex-shrink-0 mt-0.5",ge[t])}),e.jsxs("div",{className:"flex-1 text-xs leading-relaxed",children:[a&&e.jsx("div",{className:"font-medium text-ui-text mb-0.5",children:a}),n]}),i&&e.jsx("div",{className:"flex-shrink-0",children:i})]})};r.__docgenInfo={description:"",methods:[],displayName:"Notice",props:{kind:{defaultValue:{value:"'info'",computed:!1},required:!1}}};const ve={sm:"my-2",md:"my-4",lg:"my-6"},Ne={sm:"mx-2",md:"mx-4",lg:"mx-6"},ae=({orientation:t="horizontal",spacing:s="md"})=>t==="vertical"?e.jsx("span",{"aria-hidden":!0,className:d("inline-block w-px h-4 bg-ui-divider",Ne[s])}):e.jsx("div",{"aria-hidden":!0,className:d("w-full h-px bg-ui-divider",ve[s])});ae.__docgenInfo={description:"",methods:[],displayName:"Divider",props:{orientation:{defaultValue:{value:"'horizontal'",computed:!1},required:!1},spacing:{defaultValue:{value:"'md'",computed:!1},required:!1}}};const be={xs:14,sm:18,md:24,lg:32},m=({size:t="md",fullscreen:s=!1,label:a})=>{const n=e.jsxs("div",{className:"flex flex-col items-center gap-2 text-ui-text-3",children:[e.jsx(oe,{size:be[t],className:"animate-spin"}),a&&e.jsx("span",{className:"text-xs",children:a})]});return s?e.jsx("div",{className:"fixed inset-0 z-[150] flex items-center justify-center bg-black/30 backdrop-blur-sm",children:n}):n};m.__docgenInfo={description:"",methods:[],displayName:"Loading",props:{size:{defaultValue:{value:"'md'",computed:!1},required:!1},fullscreen:{defaultValue:{value:"false",computed:!1},required:!1}}};const b=({shape:t="rect",width:s="100%",height:a,count:n=1,rounded:i})=>{const o="bg-ui-bg-subtle animate-pulse",y=t==="circle"?"rounded-full":t==="line"?"rounded":i||"rounded-md",_=a||(t==="line"?"0.75em":t==="circle"?s:"1rem"),N=s,c=Array.from({length:n});return e.jsx("div",{className:"space-y-2",children:c.map((ye,ie)=>e.jsx("div",{className:d(o,y),style:{width:N,height:_}},ie))})};b.__docgenInfo={description:"",methods:[],displayName:"Skeleton",props:{shape:{defaultValue:{value:"'rect'",computed:!1},required:!1},width:{defaultValue:{value:"'100%'",computed:!1},required:!1},count:{defaultValue:{value:"1",computed:!1},required:!1}}};const je={top:"bottom-full left-1/2 -translate-x-1/2 mb-1.5",bottom:"top-full left-1/2 -translate-x-1/2 mt-1.5",left:"right-full top-1/2 -translate-y-1/2 mr-1.5",right:"left-full top-1/2 -translate-y-1/2 ml-1.5"},j=({content:t,placement:s="top",children:a})=>{const[n,i]=w.useState(!1);return e.jsxs("span",{className:"relative inline-flex",onMouseEnter:()=>i(!0),onMouseLeave:()=>i(!1),onFocus:()=>i(!0),onBlur:()=>i(!1),children:[a,n&&t&&e.jsx("span",{role:"tooltip",className:d("absolute z-50 px-2 py-1 text-[11px] font-medium whitespace-nowrap rounded-md","bg-ui-accent text-ui-accent-fg shadow-lg pointer-events-none",je[s]),children:t})]})};j.__docgenInfo={description:"",methods:[],displayName:"Tooltip",props:{placement:{defaultValue:{value:"'top'",computed:!1},required:!1}}};const Te={title:"UI/Layout & Misc"},z=({title:t,children:s})=>e.jsxs("div",{className:"mb-5",children:[e.jsx("div",{className:"text-[11px] uppercase tracking-wider text-ui-text-3 mb-2",children:t}),s]}),u=()=>e.jsxs(Q,{title:"页面标题",actions:e.jsxs(e.Fragment,{children:[e.jsx(S,{icon:de,title:"刷新"}),e.jsx(l,{icon:Z,children:"新建"})]}),children:[e.jsx(r,{children:"这是一个 Notice 横幅。"}),e.jsx("div",{className:"h-2"}),e.jsx(X,{title:"区块标题",description:"副标题描述文本",children:e.jsx("div",{className:"text-sm text-ui-text-2",children:"SectionCard 是设置页常用的小节卡片，padding=lg，radius=xxl，variant=plain。"})})]}),x=()=>{const[t,s]=w.useState("a"),a=[{value:"a",label:"订单"},{value:"b",label:"订阅"},{value:"c",label:"统计"}];return e.jsx(te,{items:a,value:t,onChange:s})},p=()=>{const[t,s]=w.useState(1);return e.jsxs("div",{className:"border border-ui-border rounded-2xl overflow-hidden bg-ui-bg-elevated max-w-[480px]",children:[e.jsx("div",{className:"p-6 text-sm text-ui-text-2",children:"这里是表格内容..."}),e.jsx(se,{page:t,pageSize:20,total:185,onChange:s})]})},h=()=>e.jsxs("div",{className:"space-y-3 max-w-[600px]",children:[e.jsx(r,{kind:"info",title:"提示",children:"Info 横幅文案。"}),e.jsx(r,{kind:"success",children:"操作成功，已应用变更。"}),e.jsx(r,{kind:"warning",title:"警告",children:"请确认后再继续操作。"}),e.jsx(r,{kind:"danger",children:"删除后不可恢复！"}),e.jsx(ae,{}),e.jsx(r,{action:e.jsx(l,{size:"sm",children:"查看"}),children:"Notice 也支持右侧 action 节点。"})]}),f=()=>e.jsxs("div",{className:"space-y-5",children:[e.jsx(z,{title:"Loading (xs/sm/md/lg)",children:e.jsxs("div",{className:"flex items-center gap-6",children:[e.jsx(m,{size:"xs"}),e.jsx(m,{size:"sm"}),e.jsx(m,{size:"md",label:"加载中"}),e.jsx(m,{size:"lg"})]})}),e.jsx(z,{title:"Skeleton",children:e.jsxs("div",{className:"max-w-[400px] space-y-2",children:[e.jsx(b,{width:"40%",height:"14px"}),e.jsx(b,{width:"100%",height:"12px",count:3}),e.jsx(b,{shape:"circle",width:"40px"})]})})]}),g=()=>e.jsxs("div",{className:"flex items-center gap-8 p-12",children:[e.jsx(j,{content:"这是顶部 tooltip",children:e.jsx(l,{children:"hover 试试"})}),e.jsx(j,{placement:"right",content:"右侧",children:e.jsx(l,{children:"right"})}),e.jsx(j,{placement:"bottom",content:"底部",children:e.jsx(l,{children:"bottom"})})]}),v=()=>e.jsx("div",{className:"max-w-[600px] border border-ui-border rounded-2xl",children:e.jsx(ee,{icon:J,title:"暂无数据",description:"点击下面的按钮创建第一个条目",action:e.jsx(l,{icon:Z,size:"sm",children:"新建"})})});u.__docgenInfo={description:"",methods:[],displayName:"PageShellDemo"};x.__docgenInfo={description:"",methods:[],displayName:"TabsDemo"};p.__docgenInfo={description:"",methods:[],displayName:"PaginationDemo"};h.__docgenInfo={description:"",methods:[],displayName:"NoticeAndDivider"};f.__docgenInfo={description:"",methods:[],displayName:"LoadingAndSkeleton"};g.__docgenInfo={description:"",methods:[],displayName:"TooltipDemo"};v.__docgenInfo={description:"",methods:[],displayName:"EmptyStateDemo"};var D,P,C;u.parameters={...u.parameters,docs:{...(D=u.parameters)==null?void 0:D.docs,source:{originalSource:`() => <PageShell title='页面标题' actions={<>
        <IconButton icon={RefreshCw} title='刷新' />
        <Button icon={Plus}>新建</Button>
      </>}>
    <Notice>这是一个 Notice 横幅。</Notice>
    <div className='h-2' />
    <SectionCard title='区块标题' description='副标题描述文本'>
      <div className='text-sm text-ui-text-2'>SectionCard 是设置页常用的小节卡片，padding=lg，radius=xxl，variant=plain。</div>
    </SectionCard>
  </PageShell>`,...(C=(P=u.parameters)==null?void 0:P.docs)==null?void 0:C.source}}};var L,T,V;x.parameters={...x.parameters,docs:{...(L=x.parameters)==null?void 0:L.docs,source:{originalSource:`() => {
  const [v, setV] = useState('a');
  const items = [{
    value: 'a',
    label: '订单'
  }, {
    value: 'b',
    label: '订阅'
  }, {
    value: 'c',
    label: '统计'
  }];
  return <Tabs items={items} value={v} onChange={setV} />;
}`,...(V=(T=x.parameters)==null?void 0:T.docs)==null?void 0:V.source}}};var B,q,E;p.parameters={...p.parameters,docs:{...(B=p.parameters)==null?void 0:B.docs,source:{originalSource:`() => {
  const [page, setPage] = useState(1);
  return <div className='border border-ui-border rounded-2xl overflow-hidden bg-ui-bg-elevated max-w-[480px]'>
      <div className='p-6 text-sm text-ui-text-2'>这里是表格内容...</div>
      <Pagination page={page} pageSize={20} total={185} onChange={setPage} />
    </div>;
}`,...(E=(q=p.parameters)==null?void 0:q.docs)==null?void 0:E.source}}};var A,R,M;h.parameters={...h.parameters,docs:{...(A=h.parameters)==null?void 0:A.docs,source:{originalSource:`() => <div className='space-y-3 max-w-[600px]'>
    <Notice kind='info' title='提示'>Info 横幅文案。</Notice>
    <Notice kind='success'>操作成功，已应用变更。</Notice>
    <Notice kind='warning' title='警告'>请确认后再继续操作。</Notice>
    <Notice kind='danger'>删除后不可恢复！</Notice>
    <Divider />
    <Notice action={<Button size='sm'>查看</Button>}>
      Notice 也支持右侧 action 节点。
    </Notice>
  </div>`,...(M=(R=h.parameters)==null?void 0:R.docs)==null?void 0:M.source}}};var O,$,K;f.parameters={...f.parameters,docs:{...(O=f.parameters)==null?void 0:O.docs,source:{originalSource:`() => <div className='space-y-5'>
    <Row title='Loading (xs/sm/md/lg)'>
      <div className='flex items-center gap-6'>
        <Loading size='xs' />
        <Loading size='sm' />
        <Loading size='md' label='加载中' />
        <Loading size='lg' />
      </div>
    </Row>
    <Row title='Skeleton'>
      <div className='max-w-[400px] space-y-2'>
        <Skeleton width='40%' height='14px' />
        <Skeleton width='100%' height='12px' count={3} />
        <Skeleton shape='circle' width='40px' />
      </div>
    </Row>
  </div>`,...(K=($=f.parameters)==null?void 0:$.docs)==null?void 0:K.source}}};var F,G,H;g.parameters={...g.parameters,docs:{...(F=g.parameters)==null?void 0:F.docs,source:{originalSource:`() => <div className='flex items-center gap-8 p-12'>
    <Tooltip content='这是顶部 tooltip'>
      <Button>hover 试试</Button>
    </Tooltip>
    <Tooltip placement='right' content='右侧'>
      <Button>right</Button>
    </Tooltip>
    <Tooltip placement='bottom' content='底部'>
      <Button>bottom</Button>
    </Tooltip>
  </div>`,...(H=(G=g.parameters)==null?void 0:G.docs)==null?void 0:H.source}}};var U,W,Y;v.parameters={...v.parameters,docs:{...(U=v.parameters)==null?void 0:U.docs,source:{originalSource:`() => <div className='max-w-[600px] border border-ui-border rounded-2xl'>
    <EmptyState icon={Inbox} title='暂无数据' description='点击下面的按钮创建第一个条目' action={<Button icon={Plus} size='sm'>新建</Button>} />
  </div>`,...(Y=(W=v.parameters)==null?void 0:W.docs)==null?void 0:Y.source}}};const Ve=["PageShellDemo","TabsDemo","PaginationDemo","NoticeAndDivider","LoadingAndSkeleton","TooltipDemo","EmptyStateDemo"];export{v as EmptyStateDemo,f as LoadingAndSkeleton,h as NoticeAndDivider,u as PageShellDemo,p as PaginationDemo,x as TabsDemo,g as TooltipDemo,Ve as __namedExportsOrder,Te as default};
