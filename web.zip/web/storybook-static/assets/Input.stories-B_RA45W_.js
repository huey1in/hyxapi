import{j as e}from"./jsx-runtime-DFAAy_2V.js";import{r as i}from"./index-Bc2G9s8g.js";import{I as a,F as u,i as x}from"./FieldRow-BkC0sE2g.js";import{S as h}from"./search-DcOwy908.js";import"./tokens-DrfCP7vW.js";import"./x-Bzu-zyl5.js";const f={title:"UI/Input",component:a},s=({title:n,children:l})=>e.jsxs("div",{className:"mb-5",children:[e.jsx("div",{className:"text-[11px] uppercase tracking-wider text-ui-text-3 mb-2",children:n}),l]}),t=()=>{const[n,l]=i.useState(""),[c,p]=i.useState("clear me");return e.jsxs("div",{className:"max-w-[600px] space-y-3",children:[e.jsx(s,{title:"variant",children:e.jsxs("div",{className:"space-y-2",children:[e.jsx(a,{variant:"admin",value:n,onChange:l,placeholder:"admin (默认 rounded-xl)"}),e.jsx(a,{variant:"auth",value:n,onChange:l,placeholder:"auth (rounded-lg + focus ring)"}),e.jsx(a,{variant:"inline",value:n,onChange:l,placeholder:"inline (rounded + bg-subtle)"})]})}),e.jsx(s,{title:"size",children:e.jsxs("div",{className:"space-y-2",children:[e.jsx(a,{size:"sm",placeholder:"sm"}),e.jsx(a,{size:"md",placeholder:"md (默认)"}),e.jsx(a,{size:"lg",placeholder:"lg"})]})}),e.jsx(s,{title:"prefix / suffix",children:e.jsxs("div",{className:"space-y-2",children:[e.jsx(a,{prefix:e.jsx(h,{size:14}),placeholder:"搜索..."}),e.jsx(a,{suffix:e.jsx("span",{className:"text-xs",children:"USD"}),placeholder:"99.00"})]})}),e.jsx(s,{title:"clearable",children:e.jsx(a,{clearable:!0,value:c,onChange:p,placeholder:"输入后可清除"})}),e.jsx(s,{title:"invalid / disabled",children:e.jsxs("div",{className:"space-y-2",children:[e.jsx(a,{invalid:!0,value:"错误状态",onChange:()=>{}}),e.jsx(a,{disabled:!0,placeholder:"禁用"})]})}),e.jsx(s,{title:"FieldRow 包装",children:e.jsx(u,{label:"套餐名称",required:!0,hint:"1-20 个字符",children:e.jsx(a,{placeholder:"输入名称"})})}),e.jsx(s,{title:"inputClass() — 用于 textarea/select/原生 input",children:e.jsx("textarea",{rows:3,className:x({variant:"admin",size:"md"})+" resize-none",placeholder:"这是原生 textarea，复用 input 样式"})})]})};t.__docgenInfo={description:"",methods:[],displayName:"AllVariants"};var r,d,o;t.parameters={...t.parameters,docs:{...(r=t.parameters)==null?void 0:r.docs,source:{originalSource:`() => {
  const [v1, setV1] = useState('');
  const [v2, setV2] = useState('clear me');
  return <div className='max-w-[600px] space-y-3'>
      <Row title='variant'>
        <div className='space-y-2'>
          <Input variant='admin' value={v1} onChange={setV1} placeholder='admin (默认 rounded-xl)' />
          <Input variant='auth' value={v1} onChange={setV1} placeholder='auth (rounded-lg + focus ring)' />
          <Input variant='inline' value={v1} onChange={setV1} placeholder='inline (rounded + bg-subtle)' />
        </div>
      </Row>
      <Row title='size'>
        <div className='space-y-2'>
          <Input size='sm' placeholder='sm' />
          <Input size='md' placeholder='md (默认)' />
          <Input size='lg' placeholder='lg' />
        </div>
      </Row>
      <Row title='prefix / suffix'>
        <div className='space-y-2'>
          <Input prefix={<Search size={14} />} placeholder='搜索...' />
          <Input suffix={<span className='text-xs'>USD</span>} placeholder='99.00' />
        </div>
      </Row>
      <Row title='clearable'>
        <Input clearable value={v2} onChange={setV2} placeholder='输入后可清除' />
      </Row>
      <Row title='invalid / disabled'>
        <div className='space-y-2'>
          <Input invalid value='错误状态' onChange={() => {}} />
          <Input disabled placeholder='禁用' />
        </div>
      </Row>
      <Row title='FieldRow 包装'>
        <FieldRow label='套餐名称' required hint='1-20 个字符'>
          <Input placeholder='输入名称' />
        </FieldRow>
      </Row>
      <Row title='inputClass() — 用于 textarea/select/原生 input'>
        <textarea rows={3} className={inputClass({
        variant: 'admin',
        size: 'md'
      }) + ' resize-none'} placeholder='这是原生 textarea，复用 input 样式' />
      </Row>
    </div>;
}`,...(o=(d=t.parameters)==null?void 0:d.docs)==null?void 0:o.source}}};const I=["AllVariants"];export{t as AllVariants,I as __namedExportsOrder,f as default};
