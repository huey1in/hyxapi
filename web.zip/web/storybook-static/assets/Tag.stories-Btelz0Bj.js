import{j as e}from"./jsx-runtime-DFAAy_2V.js";import"./index-Bc2G9s8g.js";import{T as a}from"./Tag-a08qfjaU.js";import"./tokens-DrfCP7vW.js";import"./x-Bzu-zyl5.js";const x={title:"UI/Tag",component:a},r=()=>e.jsxs("div",{className:"space-y-3",children:[e.jsxs("div",{children:[e.jsx("div",{className:"text-[11px] uppercase tracking-wider text-ui-text-3 mb-2",children:"color"}),e.jsxs("div",{className:"flex flex-wrap gap-2",children:[e.jsx(a,{children:"default"}),e.jsx(a,{color:"blue",children:"blue"}),e.jsx(a,{color:"emerald",children:"emerald"}),e.jsx(a,{color:"violet",children:"violet"}),e.jsx(a,{color:"amber",children:"amber"}),e.jsx(a,{color:"rose",children:"rose"}),e.jsx(a,{color:"cyan",children:"cyan"}),e.jsx(a,{color:"danger",children:"danger"}),e.jsx(a,{color:"success",children:"success"}),e.jsx(a,{color:"warning",children:"warning"})]})]}),e.jsxs("div",{children:[e.jsx("div",{className:"text-[11px] uppercase tracking-wider text-ui-text-3 mb-2",children:"dot"}),e.jsxs("div",{className:"flex flex-wrap gap-3",children:[e.jsx(a,{dot:!0,color:"emerald",children:"生效"}),e.jsx(a,{dot:!0,color:"rose",children:"已禁用"}),e.jsx(a,{dot:!0,color:"amber",children:"待审核"}),e.jsx(a,{dot:!0,children:"未使用"})]})]}),e.jsxs("div",{children:[e.jsx("div",{className:"text-[11px] uppercase tracking-wider text-ui-text-3 mb-2",children:"closable"}),e.jsx("div",{className:"flex flex-wrap gap-2",children:e.jsx(a,{color:"blue",closable:!0,onClose:()=>alert("close"),children:"关闭我"})})]})]});r.__docgenInfo={description:"",methods:[],displayName:"AllVariants"};var l,s,o;r.parameters={...r.parameters,docs:{...(l=r.parameters)==null?void 0:l.docs,source:{originalSource:`() => <div className='space-y-3'>
    <div>
      <div className='text-[11px] uppercase tracking-wider text-ui-text-3 mb-2'>color</div>
      <div className='flex flex-wrap gap-2'>
        <Tag>default</Tag>
        <Tag color='blue'>blue</Tag>
        <Tag color='emerald'>emerald</Tag>
        <Tag color='violet'>violet</Tag>
        <Tag color='amber'>amber</Tag>
        <Tag color='rose'>rose</Tag>
        <Tag color='cyan'>cyan</Tag>
        <Tag color='danger'>danger</Tag>
        <Tag color='success'>success</Tag>
        <Tag color='warning'>warning</Tag>
      </div>
    </div>
    <div>
      <div className='text-[11px] uppercase tracking-wider text-ui-text-3 mb-2'>dot</div>
      <div className='flex flex-wrap gap-3'>
        <Tag dot color='emerald'>生效</Tag>
        <Tag dot color='rose'>已禁用</Tag>
        <Tag dot color='amber'>待审核</Tag>
        <Tag dot>未使用</Tag>
      </div>
    </div>
    <div>
      <div className='text-[11px] uppercase tracking-wider text-ui-text-3 mb-2'>closable</div>
      <div className='flex flex-wrap gap-2'>
        <Tag color='blue' closable onClose={() => alert('close')}>关闭我</Tag>
      </div>
    </div>
  </div>`,...(o=(s=r.parameters)==null?void 0:s.docs)==null?void 0:o.source}}};const g=["AllVariants"];export{r as AllVariants,g as __namedExportsOrder,x as default};
