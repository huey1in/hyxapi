import{r as n}from"./index-Bc2G9s8g.js";/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const x=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),f=e=>e.replace(/^([A-Z])|[\s-_]+(\w)/g,(t,a,r)=>r?r.toUpperCase():a.toLowerCase()),l=e=>{const t=f(e);return t.charAt(0).toUpperCase()+t.slice(1)},c=(...e)=>e.filter((t,a,r)=>!!t&&t.trim()!==""&&r.indexOf(t)===a).join(" ").trim(),p=e=>{for(const t in e)if(t.startsWith("aria-")||t==="role"||t==="title")return!0};/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var C={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y=n.forwardRef(({color:e="currentColor",size:t=24,strokeWidth:a=2,absoluteStrokeWidth:r,className:s="",children:o,iconNode:m,...i},g)=>n.createElement("svg",{ref:g,...C,width:t,height:t,stroke:e,strokeWidth:r?Number(a)*24/Number(t):a,className:c("lucide",s),...!o&&!p(i)&&{"aria-hidden":"true"},...i},[...m.map(([d,b])=>n.createElement(d,b)),...Array.isArray(o)?o:[o]]));/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const w=(e,t)=>{const a=n.forwardRef(({className:r,...s},o)=>n.createElement(y,{ref:o,iconNode:t,className:c(`lucide-${x(l(e))}`,`lucide-${e}`,r),...s}));return a.displayName=l(e),a};function u(e){var t,a,r="";if(typeof e=="string"||typeof e=="number")r+=e;else if(typeof e=="object")if(Array.isArray(e)){var s=e.length;for(t=0;t<s;t++)e[t]&&(a=u(e[t]))&&(r&&(r+=" "),r+=a)}else for(a in e)e[a]&&(r&&(r+=" "),r+=a);return r}function v(){for(var e,t,a=0,r="",s=arguments.length;a<s;a++)(e=arguments[a])&&(t=u(e))&&(r&&(r+=" "),r+=t);return r}const h=v,A={sm:"px-2.5 py-1",md:"px-3.5 py-2",lg:"px-4 py-2.5"},E={sm:"text-xs",md:"text-sm",lg:"text-base"},I={sm:"gap-1",md:"gap-1.5",lg:"gap-2"},S={sm:12,md:14,lg:16},_="focus:outline-none focus-visible:ring-2 focus-visible:ring-ui-text focus-visible:ring-offset-1",L={default:"bg-ui-bg-subtle text-ui-text-2",blue:"bg-blue-500/10    text-blue-600    dark:text-blue-400",emerald:"bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",violet:"bg-violet-500/10  text-violet-600  dark:text-violet-400",amber:"bg-amber-500/10   text-amber-600   dark:text-amber-400",rose:"bg-rose-500/10    text-rose-600    dark:text-rose-400",cyan:"bg-cyan-500/10    text-cyan-600    dark:text-cyan-400",danger:"bg-ui-danger-bg   text-ui-danger",success:"bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",warning:"bg-amber-500/10   text-amber-600   dark:text-amber-400"};export{L as C,_ as F,S,h as a,I as b,w as c,E as d,A as e};
