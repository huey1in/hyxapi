import{j as n}from"./jsx-runtime-DFAAy_2V.js";import"./index-Bc2G9s8g.js";import{I as e}from"./IconButton-BnpmFXWU.js";import{S as t}from"./search-DcOwy908.js";import{c as x}from"./tokens-DrfCP7vW.js";import{P as c}from"./plus-CJWvk8nG.js";import{T as a}from"./trash-2-BCUJgxuz.js";import{X as r}from"./x-Bzu-zyl5.js";import{R as h}from"./refresh-cw-DF6RBdiH.js";/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const j=[["circle",{cx:"12",cy:"12",r:"1",key:"41hilf"}],["circle",{cx:"19",cy:"12",r:"1",key:"1wjl8i"}],["circle",{cx:"5",cy:"12",r:"1",key:"1pcz8c"}]],v=x("ellipsis",j);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const I=[["path",{d:"M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",key:"1a8usu"}]],o=x("pen",I),N={title:"UI/IconButton",component:e,parameters:{layout:"centered"}},i=({title:p,children:m})=>n.jsxs("div",{className:"mb-4",children:[n.jsx("div",{className:"text-[11px] uppercase tracking-wider text-ui-text-3 mb-2",children:p}),n.jsx("div",{className:"flex flex-wrap items-center gap-2",children:m})]}),s=()=>n.jsxs("div",{className:"min-w-[640px] space-y-2",children:[n.jsxs(i,{title:"size",children:[n.jsx(e,{icon:t,size:"xs"}),n.jsx(e,{icon:t,size:"sm"}),n.jsx(e,{icon:t,size:"md"}),n.jsx(e,{icon:t,size:"lg"}),n.jsx(e,{icon:t,size:"xl"})]}),n.jsxs(i,{title:"variant",children:[n.jsx(e,{icon:v,variant:"ghost"}),n.jsx(e,{icon:c,variant:"solid"}),n.jsx(e,{icon:a,variant:"danger"}),n.jsx(e,{icon:o,variant:"outline"}),n.jsx(e,{icon:c,variant:"circleSolid",shape:"circle"})]}),n.jsxs(i,{title:"shape=circle",children:[n.jsx(e,{icon:r,shape:"circle"}),n.jsx(e,{icon:c,shape:"circle",variant:"solid"}),n.jsx(e,{icon:h,shape:"circle",variant:"outline"})]}),n.jsxs(i,{title:"tone (仅 ghost 时生效)",children:[n.jsx(e,{icon:o,tone:"blue"}),n.jsx(e,{icon:o,tone:"green"}),n.jsx(e,{icon:o,tone:"yellow"}),n.jsx(e,{icon:o,tone:"purple"}),n.jsx(e,{icon:a,tone:"red"})]}),n.jsxs(i,{title:"selected",children:[n.jsx(e,{icon:o,selected:!0}),n.jsx(e,{icon:o,shape:"circle",selected:!0})]}),n.jsxs(i,{title:"disabled",children:[n.jsx(e,{icon:r,disabled:!0}),n.jsx(e,{icon:c,variant:"solid",disabled:!0})]}),n.jsx(i,{title:"absolute + position（容器需 relative）",children:n.jsx("div",{className:"relative w-[200px] h-[100px] border border-ui-border rounded-xl bg-ui-bg-subtle",children:n.jsx(e,{icon:r,size:"sm",absolute:!0,position:"tr"})})})]});s.__docgenInfo={description:"",methods:[],displayName:"AllVariants"};var l,d,u;s.parameters={...s.parameters,docs:{...(l=s.parameters)==null?void 0:l.docs,source:{originalSource:`() => <div className='min-w-[640px] space-y-2'>
    <Row title='size'>
      <IconButton icon={Search} size='xs' />
      <IconButton icon={Search} size='sm' />
      <IconButton icon={Search} size='md' />
      <IconButton icon={Search} size='lg' />
      <IconButton icon={Search} size='xl' />
    </Row>

    <Row title='variant'>
      <IconButton icon={MoreHorizontal} variant='ghost' />
      <IconButton icon={Plus} variant='solid' />
      <IconButton icon={Trash2} variant='danger' />
      <IconButton icon={Edit2} variant='outline' />
      <IconButton icon={Plus} variant='circleSolid' shape='circle' />
    </Row>

    <Row title='shape=circle'>
      <IconButton icon={X} shape='circle' />
      <IconButton icon={Plus} shape='circle' variant='solid' />
      <IconButton icon={RefreshCw} shape='circle' variant='outline' />
    </Row>

    <Row title='tone (仅 ghost 时生效)'>
      <IconButton icon={Edit2} tone='blue' />
      <IconButton icon={Edit2} tone='green' />
      <IconButton icon={Edit2} tone='yellow' />
      <IconButton icon={Edit2} tone='purple' />
      <IconButton icon={Trash2} tone='red' />
    </Row>

    <Row title='selected'>
      <IconButton icon={Edit2} selected />
      <IconButton icon={Edit2} shape='circle' selected />
    </Row>

    <Row title='disabled'>
      <IconButton icon={X} disabled />
      <IconButton icon={Plus} variant='solid' disabled />
    </Row>

    <Row title='absolute + position（容器需 relative）'>
      <div className='relative w-[200px] h-[100px] border border-ui-border rounded-xl bg-ui-bg-subtle'>
        <IconButton icon={X} size='sm' absolute position='tr' />
      </div>
    </Row>
  </div>`,...(u=(d=s.parameters)==null?void 0:d.docs)==null?void 0:u.source}}};const S=["AllVariants"];export{s as AllVariants,S as __namedExportsOrder,N as default};
