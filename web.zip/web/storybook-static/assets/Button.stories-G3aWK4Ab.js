import{j as t}from"./jsx-runtime-DFAAy_2V.js";import"./index-Bc2G9s8g.js";import{B as n}from"./Button-Yv8kz5f4.js";import{P as i}from"./plus-CJWvk8nG.js";import{c as r}from"./tokens-DrfCP7vW.js";import{S as u}from"./search-DcOwy908.js";/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const x=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]],h=r("arrow-right",x);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const m=[["path",{d:"M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",key:"1c8476"}],["path",{d:"M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7",key:"1ydtos"}],["path",{d:"M7 3v4a1 1 0 0 0 1 1h7",key:"t51u73"}]],p=r("save",m),R={title:"UI/Button",component:n,parameters:{layout:"centered"}},e=({title:c,children:d})=>t.jsxs("div",{className:"mb-4",children:[t.jsx("div",{className:"text-[11px] uppercase tracking-wider text-ui-text-3 mb-2",children:c}),t.jsx("div",{className:"flex flex-wrap items-center gap-2",children:d})]}),s=()=>t.jsxs("div",{className:"min-w-[600px] space-y-2",children:[t.jsx(e,{title:"variant",children:t.jsx(n,{children:"primary"})}),t.jsxs(e,{title:"size (sm 改用 rounded-md)",children:[t.jsx(n,{size:"sm",children:"sm"}),t.jsx(n,{size:"md",children:"md"}),t.jsx(n,{size:"lg",children:"lg"})]}),t.jsxs(e,{title:"with icon",children:[t.jsx(n,{icon:i,children:"添加"}),t.jsx(n,{icon:p,children:"保存"}),t.jsx(n,{icon:u,children:"搜索"}),t.jsx(n,{iconRight:h,children:"下一步"})]}),t.jsxs(e,{title:"loading / disabled",children:[t.jsx(n,{loading:!0,children:"提交中"}),t.jsx(n,{disabled:!0,children:"已禁用"})]}),t.jsxs(e,{title:"toggle (stateful)",children:[t.jsx(n,{variant:"toggle",selected:!0,children:"表格视图"}),t.jsx(n,{variant:"toggle",children:"卡片视图"})]}),t.jsxs(e,{title:"chip (stateful, 胶囊)",children:[t.jsx(n,{variant:"chip",selected:!0,size:"sm",children:"已选"}),t.jsx(n,{variant:"chip",size:"sm",children:"未选"})]}),t.jsx(e,{title:"block (占满父宽)",children:t.jsx("div",{className:"w-[300px]",children:t.jsx(n,{block:!0,icon:i,children:"添加渠道"})})}),t.jsx(e,{title:"flex1 (flex 行内平分)",children:t.jsxs("div",{className:"flex gap-2 w-[300px]",children:[t.jsx(n,{flex1:!0,children:"取消"}),t.jsx(n,{flex1:!0,children:"确认"})]})}),t.jsxs(e,{title:"justify=start (左对齐，菜单项)",children:[t.jsx("div",{className:"w-[200px]",children:t.jsx(n,{block:!0,justify:"start",children:"账户设置"})}),t.jsx("div",{className:"w-[200px]",children:t.jsx(n,{block:!0,justify:"start",icon:i,children:"添加项"})})]})]});s.__docgenInfo={description:"",methods:[],displayName:"AllVariants"};var o,l,a;s.parameters={...s.parameters,docs:{...(o=s.parameters)==null?void 0:o.docs,source:{originalSource:`() => <div className='min-w-[600px] space-y-2'>
    <Row title='variant'>
      <Button>primary</Button>
    </Row>

    <Row title='size (sm 改用 rounded-md)'>
      <Button size='sm'>sm</Button>
      <Button size='md'>md</Button>
      <Button size='lg'>lg</Button>
    </Row>

    <Row title='with icon'>
      <Button icon={Plus}>添加</Button>
      <Button icon={Save}>保存</Button>
      <Button icon={Search}>搜索</Button>
      <Button iconRight={ArrowRight}>下一步</Button>
    </Row>

    <Row title='loading / disabled'>
      <Button loading>提交中</Button>
      <Button disabled>已禁用</Button>
    </Row>

    <Row title='toggle (stateful)'>
      <Button variant='toggle' selected>表格视图</Button>
      <Button variant='toggle'>卡片视图</Button>
    </Row>

    <Row title='chip (stateful, 胶囊)'>
      <Button variant='chip' selected size='sm'>已选</Button>
      <Button variant='chip' size='sm'>未选</Button>
    </Row>

    <Row title='block (占满父宽)'>
      <div className='w-[300px]'>
        <Button block icon={Plus}>添加渠道</Button>
      </div>
    </Row>

    <Row title='flex1 (flex 行内平分)'>
      <div className='flex gap-2 w-[300px]'>
        <Button flex1>取消</Button>
        <Button flex1>确认</Button>
      </div>
    </Row>

    <Row title='justify=start (左对齐，菜单项)'>
      <div className='w-[200px]'>
        <Button block justify='start'>账户设置</Button>
      </div>
      <div className='w-[200px]'>
        <Button block justify='start' icon={Plus}>添加项</Button>
      </div>
    </Row>
  </div>`,...(a=(l=s.parameters)==null?void 0:l.docs)==null?void 0:a.source}}};const y=["AllVariants"];export{s as AllVariants,y as __namedExportsOrder,R as default};
